"""
calculator/views.py
منطق صفحات:
- لاگین / ثبت‌نام / خروج
- صفحه اصلی ماشین‌حساب
- API برای ذخیره و خوندن هیستوری
"""

import json
import re

from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST, require_GET
from django.contrib.auth.decorators import user_passes_test

import re

# ─── اعتبارسنجی عبارت ریاضی ──────────────────────────
SAFE_EXPRESSION = re.compile(r'^[0-9+\-*/.\s]+$')

from .models import CalculationHistory


# ════════════════════════════
#  صفحات HTML
# ════════════════════════════

def register_view(request):
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')

        if not username or not password:
            return render(request, 'calculator/register.html', {'error': 'همه فیلدها را پر کن'})

        if User.objects.filter(username=username).exists():
            return render(request, 'calculator/register.html', {'error': 'این یوزرنیم قبلاً گرفته شده'})

        # ساخت کاربر جدید — جنگو خودش رمز را هش می‌کنه (امن)
        user = User.objects.create_user(username=username, password=password)
        login(request, user)
        return redirect('calculator_home')

    return render(request, 'calculator/register.html')


def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            if user.is_superuser:
                return redirect('admin_panel')  # ادمین بره پنل
            else:
                return redirect('calculator_home')  # بقیه برن ماشین حساب
        else:
            return render(request, 'calculator/login.html', {'error': 'یوزرنیم یا رمز اشتباهه'})

    return render(request, 'calculator/login.html')


def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def calculator_view(request):
    selected_user_id = request.session.get('selected_user_id', None)
    is_admin_mode = False
    display_name = request.user.username

    if request.user.is_superuser and selected_user_id:
        try:
            target_user = User.objects.get(id=selected_user_id)
            history = CalculationHistory.objects.filter(user=target_user)[:50]
            display_name = f"{target_user.username}(admin)"
            is_admin_mode = True
        except User.DoesNotExist:
            history = CalculationHistory.objects.filter(user=request.user)[:50]
    else:
        history = CalculationHistory.objects.filter(user=request.user)[:50]

    return render(request, 'calculator/calculator.html', {
        'history': history,
        'display_name': display_name,
        'is_admin_mode': is_admin_mode,
    })

@login_required
@require_POST
def save_history_api(request):
    try:
        data = json.loads(request.body)
        expression = data.get('expression', '').strip()
        result = data.get('result', '').strip()

        if not expression or not result:
            return JsonResponse({'error': 'داده ناقصه'}, status=400)

        if not SAFE_EXPRESSION.match(expression):
            return JsonResponse({'error': 'عبارت نامعتبره'}, status=400)

        selected_user_id = request.session.get('selected_user_id', None)

        # ─── حالت ادمین (به‌جای کاربر دیگه) ───
        if request.user.is_superuser and selected_user_id:
            try:
                target_user = User.objects.get(id=selected_user_id)
                history_item = CalculationHistory.objects.create(
                    user=target_user,
                    expression=expression,
                    result=result,
                    performed_by=f"{target_user.username}(admin)",  # ← مقداردهی شده
                )
            except User.DoesNotExist:
                return JsonResponse({'error': 'یوزر پیدا نشد'}, status=400)

        # ─── حالت عادی (خود کاربر) ───
        else:
            history_item = CalculationHistory.objects.create(
                user=request.user,
                expression=expression,
                result=result,
                performed_by=request.user.username,  # ← مقداردهی شده
            )

        return JsonResponse({
            'success': True,
            'id': history_item.id,
            'created_at': history_item.created_at.strftime('%H:%M:%S'),
        })

    except json.JSONDecodeError:
        return JsonResponse({'error': 'فرمت داده اشتباهه'}, status=400)

@login_required
@require_GET
def get_history_api(request):
    selected_user_id = request.session.get('selected_user_id', None)

    if request.user.is_superuser and selected_user_id:
        try:
            target_user = User.objects.get(id=selected_user_id)
            history = CalculationHistory.objects.filter(user=target_user)[:50]
        except User.DoesNotExist:
            history = CalculationHistory.objects.filter(user=request.user)[:50]
    else:
        history = CalculationHistory.objects.filter(user=request.user)[:50]

    data = [
        {
            'id': h.id,
            'expression': h.expression,
            'result': h.result,
            'performed_by': h.performed_by,  # ← این رو حتماً اضافه کن
            'created_at': h.created_at.strftime('%Y-%m-%d %H:%M:%S'),
        }
        for h in history
    ]
    return JsonResponse({'history': data})

@login_required
@require_POST
def clear_history_api(request):
    selected_user_id = request.session.get('selected_user_id', None)

    if request.user.is_superuser and selected_user_id:
        try:
            target_user = User.objects.get(id=selected_user_id)
            CalculationHistory.objects.filter(user=target_user).delete()
        except User.DoesNotExist:
            pass
    else:
        CalculationHistory.objects.filter(user=request.user).delete()

    return JsonResponse({'success': True})

@login_required
def delete_last_history_api(request):
    if request.method != 'DELETE':
        return JsonResponse({'error': 'Method not allowed'}, status=405)

    # پیدا کردن آخرین تاریخچه‌ی کاربر (بر اساس created_at)
    last_item = CalculationHistory.objects.filter(user=request.user).first()
    
    if last_item:
        last_item.delete()
        return JsonResponse({'success': True, 'message': 'آخرین عملیات حذف شد'})
    else:
        return JsonResponse({'error': 'هیچ آیتمی برای حذف وجود ندارد'}, status=404)
    
    

@user_passes_test(lambda u: u.is_superuser)
def admin_panel_view(request):
    # همه کاربرانی که ادمین نیستن رو بگیر (به جز خودش)
    users = User.objects.exclude(is_superuser=True).order_by('username')
    return render(request, 'calculator/admin_panel.html', {'users': users})

@login_required
def select_user_view(request, user_id):
    # فقط superuser می‌تونه این کار رو بکنه
    if not request.user.is_superuser:
        return redirect('calculator_home')

    try:
        selected_user = User.objects.get(id=user_id)
        # ذخیره کاربر انتخاب‌شده در session
        request.session['selected_user_id'] = selected_user.id
        request.session['selected_username'] = selected_user.username
    except User.DoesNotExist:
        pass

    return redirect('calculator_home')